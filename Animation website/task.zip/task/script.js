  $(document).ready(function(){
    $('.slider').slick({
      infinite: true,
      slidesToShow: 3, // Number of slides to show at a time
      slidesToScroll: 1, // Number of slides to scroll
      autoplay: true, // Autoplay option
      autoplaySpeed: 2000, // Autoplay speed in milliseconds
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    });
  });